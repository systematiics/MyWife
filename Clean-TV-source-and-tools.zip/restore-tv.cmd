@echo off
cd /d "%~dp0"
where adb.exe >nul 2>nul
if errorlevel 1 if not exist adb.exe (
 echo Put this file beside adb.exe or add platform-tools to PATH.
 pause
 exit /b 1
)
adb.exe -s 192.168.1.67:5555 shell pm enable --user 0 com.vt.tv.evservice
adb.exe -s 192.168.1.67:5555 shell pm enable --user 0 com.vt.storemode
adb.exe -s 192.168.1.67:5555 shell pm enable --user 0 com.vidaa.oemtabcontentprovider
adb.exe -s 192.168.1.67:5555 shell pm enable --user 0 com.google.android.apps.tv.launcherx
adb.exe -s 192.168.1.67:5555 shell cmd package set-home-activity --user 0 com.google.android.apps.tv.launcherx/com.google.android.apps.tv.launcherx.home.HomeActivity
adb.exe -s 192.168.1.67:5555 shell input keyevent KEYCODE_HOME
pause
