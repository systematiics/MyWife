#!/usr/bin/env bash
set -euo pipefail
python3 -m venv /workspace/tv-tools/venv
/workspace/tv-tools/venv/bin/python -m pip install --no-cache-dir 'adb-shell==0.4.4'
/workspace/tv-tools/venv/bin/python -m pip check
export JAVA_HOME='/workspace/tv-tools/jdk/jdk-21.0.8+9'
export ANDROID_HOME=/workspace/android-sdk
export GRADLE_USER_HOME=/workspace/tv-tools/gradle-cache
if [ ! -x "$JAVA_HOME/bin/javac" ]; then
  curl -fLsS 'https://github.com/adoptium/temurin21-binaries/releases/download/jdk-21.0.8%2B9/OpenJDK21U-jdk_x64_linux_hotspot_21.0.8_9.tar.gz' -o /tmp/clean-tv-jdk.tar.gz
  curl -fLsS 'https://github.com/adoptium/temurin21-binaries/releases/download/jdk-21.0.8%2B9/OpenJDK21U-jdk_x64_linux_hotspot_21.0.8_9.tar.gz.sha256.txt' -o /tmp/clean-tv-jdk.sha256
  python3 - <<'PY'
import hashlib,pathlib,tarfile
p=pathlib.Path('/tmp/clean-tv-jdk.tar.gz')
assert hashlib.sha256(p.read_bytes()).hexdigest()==pathlib.Path('/tmp/clean-tv-jdk.sha256').read_text().split()[0]
with tarfile.open(p) as t:t.extractall('/workspace/tv-tools/jdk',filter='data')
PY
fi
if [ ! -x /workspace/tv-tools/gradle-8.13/bin/gradle ]; then
  curl -fLsS https://services.gradle.org/distributions/gradle-8.13-bin.zip -o /tmp/clean-tv-gradle.zip
  python3 - <<'PY'
import hashlib,pathlib,zipfile
p=pathlib.Path('/tmp/clean-tv-gradle.zip')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='20f1b1176237254a6fc204d8434196fa11a4cfb387567519c61556e8710aed78'
with zipfile.ZipFile(p) as z:z.extractall('/workspace/tv-tools')
PY
  chmod +x /workspace/tv-tools/gradle-8.13/bin/gradle
fi
if [ ! -x /workspace/android-sdk/sdk-tools/cmdline-tools/bin/sdkmanager ]; then
  curl -fLsS https://dl.google.com/android/repository/commandlinetools-linux-13114758_latest.zip -o /tmp/clean-tv-sdk.zip
  mkdir -p /workspace/android-sdk/sdk-tools
  unzip -q /tmp/clean-tv-sdk.zip -d /workspace/android-sdk/sdk-tools
fi
python3 - <<'PY'
import os,subprocess,urllib.parse
options=['-Duser.home=/workspace/tv-build-home','-Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts']
for protocol in ('http','https'):
    raw=os.environ.get(protocol.upper()+'_PROXY') or os.environ.get(protocol+'_proxy')
    if raw:
        u=urllib.parse.urlparse(raw)
        if u.username or u.password:raise RuntimeError('Authenticated proxy requires supported Java credential configuration')
        options += [f'-D{protocol}.proxyHost={u.hostname}',f'-D{protocol}.proxyPort={u.port or 80}']
e=os.environ.copy();e['JAVA_TOOL_OPTIONS']=' '.join(options)
sdk='/workspace/android-sdk/sdk-tools/cmdline-tools/bin/sdkmanager'
if not os.path.isfile('/workspace/android-sdk/platforms/android-35/android.jar'):
    subprocess.run([sdk,'--sdk_root=/workspace/android-sdk','--licenses'],input='y\n'*100,text=True,env=e,check=True)
subprocess.run([sdk,'--sdk_root=/workspace/android-sdk','platforms;android-35','build-tools;35.0.0'],env=e,check=True)
subprocess.run(['/workspace/tv-tools/gradle-8.13/bin/gradle','--no-daemon',':app:assembleDebug',':app:lintDebug',':app:testDebugUnitTest'],cwd='/workspace/tv-launcher',env=e,check=True)
PY
