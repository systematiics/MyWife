param(
    [string]$Adb = "adb.exe",
    [string]$Tv = "192.168.1.67:5555",
    [switch]$Build
)
$ErrorActionPreference = "Stop"
Push-Location $PSScriptRoot
try {
    if ($Build) {
        & .\gradlew.bat --no-daemon :app:assembleDebug :app:lintDebug
        if ($LASTEXITCODE -ne 0) { throw "Build failed" }
        $apk = Join-Path $PSScriptRoot "app\build\outputs\apk\debug\app-debug.apk"
    } else {
        $apk = Join-Path $PSScriptRoot "Clean-TV-debug.apk"
    }
    if (!(Test-Path $apk)) { throw "APK missing: $apk" }
    & $Adb -s $Tv get-state
    if ($LASTEXITCODE -ne 0) { throw "TV is not connected/authorized" }
    & $Adb -s $Tv push $apk /data/local/tmp/clean-tv.apk
    if ($LASTEXITCODE -ne 0) { throw "APK transfer failed" }
    & $Adb -s $Tv shell pm install -r /data/local/tmp/clean-tv.apk
    if ($LASTEXITCODE -ne 0) { throw "Installation failed; preserve the stock launcher" }
    & $Adb -s $Tv shell am start -n tv.cleanhome/.MainActivity
    if ($LASTEXITCODE -ne 0) { throw "Could not launch Clean TV" }
    Write-Host "Stock Home is unchanged. Inspect the launcher before changing defaults."
} finally { Pop-Location }
