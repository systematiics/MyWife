package tv.cleanhome;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.tv.*;
import android.net.wifi.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import androidx.recyclerview.widget.*;
import androidx.dynamicanimation.animation.*;
import org.json.*;
import java.util.*;
import java.text.SimpleDateFormat;
import java.util.concurrent.*;

public class MainActivity extends Activity {
 final ArrayList<App> apps=new ArrayList<>(), dock=new ArrayList<>(), grid=new ArrayList<>();
 final ArrayList<View> top=new ArrayList<>(), dockViews=new ArrayList<>();
 final Handler handler=new Handler(Looper.getMainLooper());
 final ExecutorService images=Executors.newSingleThreadExecutor();
 final android.util.LruCache<String,Bitmap> cache=new android.util.LruCache<String,Bitmap>(6*1024*1024){protected int sizeOf(String k,Bitmap v){return v.getByteCount();}};
 SpringAnimation glassX, glassY;
 FrameLayout root, glass; ScrollView scroll; LinearLayout body; RecyclerView recycler;
 TextView clock,date,hero,wifi; View glow; Typeface face; String lastPackage="",background="#000000"; int lastSection=1, lastIndex=0; boolean restoring=false;
 final Runnable tick=new Runnable(){public void run(){if(clock!=null){clock.setText(new SimpleDateFormat("h:mm",Locale.getDefault()).format(new Date()));date.setText(new SimpleDateFormat("EEEE, MMMM d",Locale.getDefault()).format(new Date()));}handler.postDelayed(this,60000);}};
 static class App {String pkg,name; android.content.ComponentName component; ResolveInfo info; App(ResolveInfo r,PackageManager pm){info=r;pkg=r.activityInfo.packageName;name=r.loadLabel(pm).toString();component=new ComponentName(pkg,r.activityInfo.name);} }

 class AmbientBackground extends Drawable {
  final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG); final String style;
  AmbientBackground(String style){this.style=style;}
  @Override public void draw(Canvas c){
   android.graphics.Rect bounds=getBounds();float w=bounds.width(),h=bounds.height();if(w<=0||h<=0)return;
   boolean violet=style.equals("violet")||style.equals("lavender");
   paint.setShader(new LinearGradient(0,0,w,h,new int[]{violet?0xff251d35:0xff07111f,violet?0xff171424:0xff070b12,violet?0xff090d16:0xff030507},null,Shader.TileMode.CLAMP));c.drawRect(bounds,paint);
   paint.setShader(new RadialGradient(w*.16f,h*.18f,w*.68f,new int[]{violet?0x789f86cd:0x30204b7c,0x00000000},null,Shader.TileMode.CLAMP));c.drawRect(bounds,paint);
   paint.setShader(new RadialGradient(w*.92f,h*.75f,w*.56f,new int[]{violet?0x404e3a78:0x18234656,0x00000000},null,Shader.TileMode.CLAMP));c.drawRect(bounds,paint);paint.setShader(null);
  }
  @Override public void setAlpha(int alpha){} @Override public void setColorFilter(ColorFilter f){} @Override public int getOpacity(){return PixelFormat.OPAQUE;}
 }
 String readConfig() throws java.io.IOException {try(java.io.InputStream in=getAssets().open("config.json");java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream()){byte[] buf=new byte[4096];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);return out.toString("UTF-8");}}
 int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
 public void onCreate(Bundle b){super.onCreate(b);getWindow().getDecorView().setSystemUiVisibility(5894);face=Typeface.create(Typeface.createFromAsset(getAssets(),"Outfit.ttf"),400,false);lastPackage=getPreferences(0).getString("last","");lastSection=getPreferences(0).getInt("section",1);lastIndex=getPreferences(0).getInt("index",0);loadApps();build();}
 void loadApps(){
  apps.clear();dock.clear();grid.clear(); PackageManager pm=getPackageManager();Set<String> seen=new HashSet<>();
  for(ResolveInfo r:pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER),0))if(!r.activityInfo.packageName.equals(getPackageName())&&seen.add(r.activityInfo.packageName)) apps.add(new App(r,pm));
  apps.sort((a,b)->a.name.compareToIgnoreCase(b.name));
  try{JSONObject c=new JSONObject(readConfig());background=c.optString("background","#000000");JSONArray d=c.getJSONArray("dock");for(int i=0;i<d.length();i++)for(App a:apps)if(a.pkg.equals(d.getString(i)))dock.add(a);}catch(Exception e){Toast.makeText(this,"Could not read launcher configuration",Toast.LENGTH_LONG).show();}
  for(App a:apps)if(!dock.contains(a))grid.add(a);
 }
 TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTypeface(face);t.setTextSize(size);t.setTextColor(color);return t;}
 GradientDrawable round(int color,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;}
 LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
 void build(){
  top.clear();dockViews.clear();root=new FrameLayout(this);try{root.setBackgroundColor(Color.parseColor(background));}catch(Exception e){root.setBackgroundColor(Color.BLACK);}try{String style=new JSONObject(readConfig()).optString("background_style","black");if(!style.equals("black"))root.setBackground(new AmbientBackground(style));}catch(Exception ignored){}try(java.io.InputStream in=getAssets().open("wallpaper.jpg")){BitmapFactory.Options o=new BitmapFactory.Options();o.inJustDecodeBounds=true;BitmapFactory.decodeStream(in,null,o);o.inJustDecodeBounds=false;o.inSampleSize=1;while(o.outWidth/o.inSampleSize>1920||o.outHeight/o.inSampleSize>1080)o.inSampleSize*=2;try(java.io.InputStream image=getAssets().open("wallpaper.jpg")){Bitmap b=BitmapFactory.decodeStream(image,null,o);if(b!=null){BitmapDrawable bg=new BitmapDrawable(getResources(),b);bg.setGravity(Gravity.FILL);root.setBackground(bg);}}}catch(java.io.IOException ignored){}setContentView(root);
  scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setClipToPadding(false);scroll.setVerticalScrollBarEnabled(false);root.addView(scroll,new FrameLayout.LayoutParams(-1,-1));
  body=vertical();body.setPadding(dp(44),dp(27),dp(44),dp(30));scroll.addView(body,new ScrollView.LayoutParams(-1,-2));
  LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);body.addView(header,new LinearLayout.LayoutParams(-1,dp(102)));
  LinearLayout time=vertical();TextView greeting=text("Welcome home",15,0xffb4bac5);try{JSONObject c=new JSONObject(readConfig());greeting.setText(c.optString("greeting","Welcome home"));}catch(Exception ignored){}
  time.addView(greeting);clock=text("",48,0xfff4f5f7);clock.setFontFeatureSettings("tnum");clock.setTypeface(Typeface.create(face,200,false));time.addView(clock);date=text("",13,0xff969da9);time.addView(date);header.addView(time,new LinearLayout.LayoutParams(0,-2,1));
  TextView inputs=pill("Inputs");wifi=pill("Wi-Fi");TextView settings=pill("Settings");for(TextView t:new TextView[]{inputs,wifi,settings}){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,dp(40));p.leftMargin=dp(10);header.addView(t,p);top.add(t);}inputs.setOnClickListener(v->showInputs(inputs));wifi.setOnClickListener(v->open(new Intent(Settings.ACTION_WIFI_SETTINGS)));settings.setOnClickListener(v->open(new Intent(Settings.ACTION_SETTINGS)));
  for(int i=0;i<top.size();i++){final int index=i;View t=top.get(i);t.setOnFocusChangeListener((v,f)->{if(f){lastSection=0;lastIndex=index;focus(v,null);}});t.setOnKeyListener((v,k,e)->navigate(0,index,k,e));}
  FrameLayout feature=new FrameLayout(this);body.addView(feature,new LinearLayout.LayoutParams(-1,dp(130)));glow=new View(this);feature.addView(glow,new FrameLayout.LayoutParams(-1,-1));hero=text(dock.isEmpty()?"Your apps":dock.get(0).name,30,0xffedf1f7);hero.setTypeface(Typeface.create(face,300,false));FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM);hp.bottomMargin=dp(20);hp.leftMargin=dp(12);feature.addView(hero,hp);
  LinearLayout band=new LinearLayout(this);band.setGravity(Gravity.CENTER);band.setPadding(dp(14),dp(10),dp(14),dp(5));band.setBackground(round(0xe6111721,22));body.addView(band,new LinearLayout.LayoutParams(-1,dp(128)));
  for(int i=0;i<dock.size();i++){final int index=i;View tile=tile(dock.get(i),1,index);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);p.setMargins(dp(8),0,dp(8),0);band.addView(tile,p);dockViews.add(tile);}
  TextView all=text("All apps",17,0xffa8afbc);LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,dp(54));all.setGravity(Gravity.BOTTOM);all.setPadding(dp(10),0,0,dp(12));body.addView(all,ap);
  recycler=new RecyclerView(this);recycler.setLayoutManager(new GridLayoutManager(this,4));recycler.setNestedScrollingEnabled(false);recycler.setItemAnimator(null);recycler.setFocusable(false);recycler.setClipChildren(false);recycler.setClipToPadding(false);recycler.setAdapter(new RecyclerView.Adapter<Holder>(){
   public Holder onCreateViewHolder(ViewGroup parent,int type){FrameLayout f=new FrameLayout(MainActivity.this);f.setClipChildren(false);f.setPadding(dp(8),dp(8),dp(8),dp(8));f.setLayoutParams(new RecyclerView.LayoutParams(-1,dp(124)));return new Holder(f);}
   public void onBindViewHolder(Holder h,int pos){FrameLayout f=(FrameLayout)h.itemView;f.removeAllViews();f.addView(tile(grid.get(pos),2,pos),new FrameLayout.LayoutParams(-1,-1));}
   public int getItemCount(){return grid.size();}
  });body.addView(recycler,new LinearLayout.LayoutParams(-1,dp(((grid.size()+3)/4)*124)));
  glass=new FrameLayout(this);GradientDrawable glassBg=round(0x08d9e7ff,16);glassBg.setStroke(dp(1),0x50e1edff);glass.setBackground(glassBg);glass.setFocusable(false);glass.setClickable(false);glass.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);glass.setAlpha(.8f);root.addView(glass,new FrameLayout.LayoutParams(dp(10),dp(10)));glass.setVisibility(View.INVISIBLE);glassX=new SpringAnimation(glass,DynamicAnimation.TRANSLATION_X).setSpring(new SpringForce().setDampingRatio(.85f).setStiffness(500f));glassY=new SpringAnimation(glass,DynamicAnimation.TRANSLATION_Y).setSpring(new SpringForce().setDampingRatio(.85f).setStiffness(500f));
  root.getViewTreeObserver().addOnScrollChangedListener(()->{View f=root.findFocus();if(f!=null)placeGlass(f,false);});
  root.post(()->{restoreFocus();});
 }
 static class Holder extends RecyclerView.ViewHolder{Holder(View v){super(v);}}
 void setArtwork(ImageView image,Bitmap bitmap){androidx.core.graphics.drawable.RoundedBitmapDrawable artwork=androidx.core.graphics.drawable.RoundedBitmapDrawableFactory.create(getResources(),bitmap);artwork.setCornerRadius(dp(8));artwork.setAntiAlias(true);image.setImageDrawable(artwork);}
 TextView pill(String label){TextView t=text(label,14,0xffe9edf4);t.setGravity(Gravity.CENTER);t.setPadding(dp(17),0,dp(17),0);t.setMaxWidth(dp(190));t.setSingleLine(true);t.setEllipsize(android.text.TextUtils.TruncateAt.END);t.setBackground(round(0xcc202936,22));t.setFocusable(true);t.setFocusableInTouchMode(true);return t;}
 View tile(App a,int section,int index){
  LinearLayout box=vertical();box.setGravity(Gravity.CENTER);box.setFocusable(true);box.setFocusableInTouchMode(true);box.setClipChildren(false);box.setTag(a.pkg);box.setPadding(dp(6),dp(4),dp(6),0);
  ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.CENTER_INSIDE);LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,0,1);box.addView(image,ip);
  TextView label=text(a.name,13,0xffe9edf4);label.setSingleLine(true);label.setEllipsize(android.text.TextUtils.TruncateAt.END);label.setGravity(Gravity.CENTER);label.setAlpha(0f);box.addView(label,new LinearLayout.LayoutParams(-1,dp(24)));
  Bitmap cached=cache.get(a.pkg);if(cached!=null)setArtwork(image,cached);else images.execute(()->{try{Drawable d=a.info.activityInfo.loadBanner(getPackageManager());if(d==null)d=a.info.loadIcon(getPackageManager());float scale=Math.min((float)dp(160)/Math.max(1,d.getIntrinsicWidth()),(float)dp(90)/Math.max(1,d.getIntrinsicHeight()));int w=Math.max(1,Math.round(Math.max(1,d.getIntrinsicWidth())*scale)),h=Math.max(1,Math.round(Math.max(1,d.getIntrinsicHeight())*scale));Bitmap bm=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(bm);d.setBounds(0,0,w,h);d.draw(c);cache.put(a.pkg,bm);handler.post(()->setArtwork(image,bm));}catch(Exception ignored){}});
  box.setOnClickListener(v->launch(a));box.setOnKeyListener((v,k,e)->navigate(section,index,k,e));
  box.setOnFocusChangeListener((v,f)->{label.animate().alpha(f?1f:0f).setDuration(120).start();new SpringAnimation(v,DynamicAnimation.SCALE_X,f?1.045f:1f).setSpring(new SpringForce(f?1.045f:1f).setDampingRatio(.8f).setStiffness(450f)).start();new SpringAnimation(v,DynamicAnimation.SCALE_Y,f?1.045f:1f).setSpring(new SpringForce(f?1.045f:1f).setDampingRatio(.8f).setStiffness(450f)).start();if(f){lastSection=section;lastIndex=index;lastPackage=a.pkg;focus(v,section==1?a:null);}});
  return box;
 }
 void focus(View v,App a){v.post(()->placeGlass(v,true));if(a!=null){hero.setText(a.name);Bitmap b=cache.get(a.pkg);int col=0xff4a607d;if(b!=null){long red=0,green=0,blue=0;int count=0;for(int y=0;y<b.getHeight();y+=8)for(int x=0;x<b.getWidth();x+=8){int p=b.getPixel(x,y);if(Color.alpha(p)>180&&(Color.red(p)+Color.green(p)+Color.blue(p))>70){red+=Color.red(p);green+=Color.green(p);blue+=Color.blue(p);count++;}}if(count>0)col=Color.rgb((int)(red/count),(int)(green/count),(int)(blue/count));}GradientDrawable aura=new GradientDrawable();aura.setGradientType(GradientDrawable.RADIAL_GRADIENT);aura.setGradientCenter(.23f,.5f);aura.setGradientRadius(dp(62));aura.setColors(new int[]{(col&0x00ffffff)|0x20000000,0x00000000});glow.setBackground(aura);hero.setTextColor(0xffeef2f8);} }
 void placeGlass(View target,boolean animate){if(glass==null||target.getWidth()==0)return;int[] p=new int[2],r=new int[2];target.getLocationInWindow(p);root.getLocationInWindow(r);FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)glass.getLayoutParams();lp.width=target.getWidth()+dp(6);lp.height=target.getHeight()+dp(6);glass.setLayoutParams(lp);float x=p[0]-r[0]-dp(3),y=p[1]-r[1]-dp(3);if(!animate||glass.getVisibility()!=View.VISIBLE){glassX.cancel();glassY.cancel();glass.setTranslationX(x);glass.setTranslationY(y);}else{glassX.animateToFinalPosition(x);glassY.animateToFinalPosition(y);}glass.setVisibility(View.VISIBLE);}
 boolean navigate(int section,int index,int key,KeyEvent e){if(e.getAction()!=KeyEvent.ACTION_DOWN)return false;boolean direction=key==19||key==20||key==21||key==22;if(!direction)return false;
  if(section==0){if(key==21)go(0,Math.max(0,index-1));if(key==22)go(0,Math.min(top.size()-1,index+1));if(key==20)go(1,Math.min(lastDock(),Math.max(0,dock.size()-1)));return true;}
  if(section==1){if(key==19)go(0,0);if(key==20&&!grid.isEmpty())go(2,Math.min(index,grid.size()-1));if(key==21)go(1,Math.max(0,index-1));if(key==22)go(1,Math.min(dock.size()-1,index+1));return true;}
  if(key==19){if(index<4)go(1,Math.min(index,Math.max(0,dock.size()-1)));else go(2,index-4);}if(key==20&&index+4<grid.size())go(2,index+4);if(key==21&&index%4>0)go(2,index-1);if(key==22&&index%4<3&&index+1<grid.size())go(2,index+1);return true;
 }
 int lastDock(){for(int i=0;i<dock.size();i++)if(dock.get(i).pkg.equals(lastPackage))return i;return 0;}
 void go(int section,int index){if(section==0){scroll.smoothScrollTo(0,0);top.get(Math.max(0,Math.min(index,top.size()-1))).requestFocus();}else if(section==1){if(dockViews.isEmpty()){if(!grid.isEmpty())go(2,0);return;}scroll.smoothScrollTo(0,0);dockViews.get(Math.max(0,Math.min(index,dockViews.size()-1))).requestFocus();}else if(!grid.isEmpty()){int i=Math.max(0,Math.min(index,grid.size()-1));RecyclerView.ViewHolder h=recycler.findViewHolderForAdapterPosition(i);if(h!=null){View t=((ViewGroup)h.itemView).getChildAt(0);t.requestFocus();android.graphics.Rect rect=new android.graphics.Rect();t.getDrawingRect(rect);t.requestRectangleOnScreen(rect,false);}else recycler.post(()->go(2,i));}}
 void restoreFocus(){if(restoring)return;restoring=true;int s=lastSection,i=lastIndex;if(!lastPackage.isEmpty()&&s!=0){ArrayList<App> list=s==1?dock:grid;for(int n=0;n<list.size();n++)if(list.get(n).pkg.equals(lastPackage)){i=n;break;}}go(s,i);restoring=false;}
 void launch(App a){try{startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER).setComponent(a.component).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));}catch(Exception e){Toast.makeText(this,"Unable to open "+a.name,Toast.LENGTH_LONG).show();}}
 void open(Intent intent){try{startActivity(intent);}catch(Exception e){Toast.makeText(this,"This setting is unavailable on this TV",Toast.LENGTH_LONG).show();}}
 void showInputs(View anchor){
  PopupMenu menu=new PopupMenu(this,anchor);TvInputManager manager=(TvInputManager)getSystemService(TV_INPUT_SERVICE);List<TvInputInfo> list=manager.getTvInputList();int id=0;
  for(TvInputInfo input:list){if(input.isHidden(this))continue;String label=input.loadLabel(this).toString();CharSequence custom=input.loadCustomLabel(this);if(custom!=null)label=custom.toString();final TvInputInfo selected=input;menu.getMenu().add(0,id++,0,label).setOnMenuItemClickListener(item->{if(selected.isPassthroughInput())open(new Intent(Intent.ACTION_VIEW,TvContract.buildChannelUriForPassthroughInput(selected.getId())));else{Intent live=getPackageManager().getLeanbackLaunchIntentForPackage("com.vt.tv.tvcenter");if(live!=null)open(live);else open(new Intent(Intent.ACTION_VIEW,TvContract.Channels.CONTENT_URI));}return true;});}
  if(id==0)menu.getMenu().add("Open TV input settings").setOnMenuItemClickListener(item->{open(new Intent("android.settings.TV_INPUT_SETTINGS"));return true;});menu.show();
 }
 protected void onResume(){super.onResume();handler.removeCallbacks(tick);tick.run();if(wifi!=null){String name="Wi-Fi";try{WifiManager wm=(WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE);String ssid=wm.getConnectionInfo().getSSID();if(ssid!=null&&!ssid.equals("<unknown ssid>"))name=ssid.replace("\"","");}catch(Exception ignored){}wifi.setText(name);}if(root!=null)root.post(this::restoreFocus);}
 protected void onPause(){getPreferences(0).edit().putString("last",lastPackage).putInt("section",lastSection).putInt("index",lastIndex).apply();handler.removeCallbacks(tick);super.onPause();}
 protected void onDestroy(){handler.removeCallbacksAndMessages(null);images.shutdownNow();super.onDestroy();}
 @Override public void onBackPressed(){go(1,lastDock());}
}
