package tv.cleanhome;
import android.content.*;
import android.content.pm.*;
import android.os.Looper;
import android.view.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;
import org.robolectric.android.controller.ActivityController;
import static org.junit.Assert.*;
import static org.robolectric.Shadows.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=31, qualifiers="w960dp-h540dp-land-xhdpi")
public class NavigationTest {
 ActivityController<MainActivity> controller;
 MainActivity activity;
 @Before public void start(){
  Intent query=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
  String[] pkgs={"com.google.android.youtube.tv","com.netflix.ninja","com.disney.disneyplus","com.hulu.livingroomplus","example.a","example.b","example.c","example.d","example.e","example.f"};
  for(String pkg:pkgs){ResolveInfo r=new ResolveInfo();r.nonLocalizedLabel=pkg;r.activityInfo=new ActivityInfo();r.activityInfo.name=pkg+".Main";r.activityInfo.packageName=pkg;r.activityInfo.enabled=true;r.activityInfo.exported=true;r.activityInfo.applicationInfo=new ApplicationInfo();r.activityInfo.applicationInfo.packageName=pkg;r.activityInfo.applicationInfo.enabled=true;shadowOf(RuntimeEnvironment.getApplication().getPackageManager()).addResolveInfoForIntent(query,r);}
  controller=Robolectric.buildActivity(MainActivity.class).setup().visible().windowFocusChanged(true);activity=controller.get();shadowOf(Looper.getMainLooper()).idle();
 }
 @After public void stop(){controller.pause().stop().destroy();}
 @Test public void discoversAppsAndHonorsDockOrder(){assertEquals(10,activity.apps.size());assertEquals(6,activity.grid.size());assertEquals("com.google.android.youtube.tv",activity.dock.get(0).pkg);assertEquals("com.netflix.ninja",activity.dock.get(1).pkg);assertEquals("com.disney.disneyplus",activity.dock.get(2).pkg);assertEquals("com.hulu.livingroomplus",activity.dock.get(3).pkg);}
 @Test public void gridMovesExactlyOneRowAndDoesNotWrap(){activity.go(2,0);shadowOf(Looper.getMainLooper()).idle();press(KeyEvent.KEYCODE_DPAD_DOWN);assertEquals("example.e",activity.getWindow().getDecorView().findFocus().getTag());press(KeyEvent.KEYCODE_DPAD_UP);assertEquals("example.a",activity.getWindow().getDecorView().findFocus().getTag());press(KeyEvent.KEYCODE_DPAD_LEFT);assertEquals("example.a",activity.getWindow().getDecorView().findFocus().getTag());}
 @Test public void topBarEndsStayInTopBar(){activity.go(0,0);press(KeyEvent.KEYCODE_DPAD_LEFT);assertSame(activity.top.get(0),activity.getWindow().getDecorView().findFocus());press(KeyEvent.KEYCODE_DPAD_UP);assertSame(activity.top.get(0),activity.getWindow().getDecorView().findFocus());activity.go(0,2);press(KeyEvent.KEYCODE_DPAD_RIGHT);assertSame(activity.top.get(2),activity.getWindow().getDecorView().findFocus());}
 @Test public void dockMovesToTopAndLaunchesExplicitApp(){activity.go(1,1);press(KeyEvent.KEYCODE_DPAD_UP);assertSame(activity.top.get(0),activity.getWindow().getDecorView().findFocus());activity.go(1,1);activity.getWindow().getDecorView().findFocus().performClick();Intent launched=shadowOf(activity).getNextStartedActivity();assertEquals("com.netflix.ninja",launched.getComponent().getPackageName());}
 void press(int key){View v=activity.getWindow().getDecorView().findFocus();assertNotNull(v);v.dispatchKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN,key));shadowOf(Looper.getMainLooper()).idle();}
}
